@extends('layouts.loggedIn')

@section('title') Booking Details | #{{$booking->id}} @endsection

@section('content')
<section class="gr-user-details">
<div class="shadow-wrapper">
        <div class="custom-description">
            <h2>Booking Detail's</h2>
            <p><span>Booking ID   </span> #{{$booking->id}}</p>
            <p><span>Booking Date </span> {{date('Y M d',strtotime($booking->booking_date))}}</p>
            <p><span>Booking Time </span> {{date('H:i A',strtotime($booking->booking_time))}}</p>
            <p><span>Service      </span> {{$booking->category_name}} > {{$booking->service_name}}</p>
            <p><span>Service Cost </span> {{$booking->service_cost}}</p>
            <p><span>Booking Status </span>  
                                @switch($booking->booking_status)
                                @case('1')
                                  Accept
                                @break
                                @default
                                  Pending
                                @endswitch </p>
            <p><span>Payment Status :</span> {{$booking->payment_status ? 'Paid' : 'Due'}}</p>
        </div>
    </div>
    <br>
    <div class="shadow-wrapper">
        <div class="custom-description">
            <h2>User Detail's</h2>
            <p><span>ID      </span> #{{$booking->user_id}}</p>
            <p><span>RUT     </span> {{$booking->user->rut_number ?? '-'}}</p>
            <p><span>Name    </span> {{$booking->user->name  ?? '-'}}</p>
            <p><span>Phone   </span> {{$booking->user->phone ?? '-'}}</p>
            <p><span>Email   </span> {{$booking->user->email ?? '-'}}</p>
        </div>
    </div>
    <br>
</section>
@include('components.backBtn')
@endsection
@push('js')
@endpush
