<section class="text-right" style="margin-bottom:20px">
    <a href="{{ url()->previous() }}" class="btn btn-primary">Back</a>
</section>