@extends('layouts.loggedIn')

@section('title') User | {{$data['user']->name}} @endsection

@section('content')
<section class="gr-user-details">
    <div class="shadow-wrapper">
        <div class="custom-img-txt clearfix">
            <div class="img">
                <img src="{{$data['user']->profile_image}}" alt="{{$data['user']->name}}">
            </div>
            <div class="txt">
               <p> <i class="fa fa-universal-access"></i> {{$data['user']->rut_number ?? '-'}}</p>
                <p> <i class="fa fa-user"></i> {{$data['user']->name}}</p>
                <p> <i class="fa fa-envelope"></i> {{$data['user']->email}}</p>
                <p> <i class="fa fa-phone"></i>{{$data['user']->phone}}</p>
                <p> <i class="fa fa-circle" @if($data['user']->is_active == '1') style="color:green" @else style="color:red"  @endif></i>{{$data['user']->is_active == '1' ? 'Active' : 'Deactive'}}</p>
            </div>
        </div>
        <div class="c-border"></div>
        <div class="custom-description">
            <h2>Other Detail's</h2>
            <p><span>Address:</span> {{$data['user']->address}}</p>
            <p><span>Total Bookings:</span> {{$data['user']->totalBookings($data['user']->id)}}&nbsp;<a href="{{route('products',['user'=>$data['user']->id])}}">(See Bookings)</a></p>
        </div>
        <br/>
        <div class="btn-wrapper">
            <button class="btn btn-dlt btn-danger">Delete</button>
            @if($data['user']->is_active == '1')
            <button class="btn btn-deactive btn-primary">Deactive</button>
            @else
            <button class="btn btn-active btn-primary">Active</button>
            @endif
        </div>
    </div>
</section>

 <!-- Modal -->
 <div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog modal-md">
        <form class="form" action="{{route('delete.user')}}" method="POST">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Delete user</h4>
        </div>
        <div class="modal-body">
                @csrf
                {{ method_field('DELETE') }}
                 <input type="hidden" name="id" value="{{$data['user']->id}}">
                 <div class="form-group">
                      <textarea class="form-control" name="reason" placeholder="Why are you delete this user account?(Optional)"></textarea>
                 </div>
                 <label><input type="checkbox" name="is_notify" checked value="1"/>&nbsp;&nbsp;&nbsp;Notify to user</label>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
          <input type="submit" class="btn btn-danger" value="Delete" />
        </div>
      </div>
    </form>
    </div>
  </div>
</div>

 <!-- Modal -->
 <div class="modal fade" id="deactiveModal" role="dialog">
    <div class="modal-dialog modal-md">
        <form class="form" action="{{route('deactive.user')}}" method="POST">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Deactive user</h4>
        </div>
        <div class="modal-body">
                @csrf
                {{ method_field('PUT') }}
                 <input type="hidden" name="id" value="{{$data['user']->id}}">
                 <div class="form-group">
                      <textarea class="form-control" name="reason" placeholder="Why are you deactive this user account?(Optional)"></textarea>
                 </div>
                 <label><input type="checkbox" name="is_notify" checked value="1"/>&nbsp;&nbsp;&nbsp;Notify to user</label>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
          <input type="submit" class="btn btn-primary" value="Deactive" />
        </div>
      </div>
    </form>
    </div>
  </div>

   <!-- Modal -->
 <div class="modal fade" id="activeModal" role="dialog">
    <div class="modal-dialog modal-md">
        <form class="form" action="{{route('active.user')}}" method="POST">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Active user</h4>
        </div>
        <div class="modal-body">
                @csrf
                {{ method_field('PUT') }}
                 <input type="hidden" name="id" value="{{$data['user']->id}}">
                 <label><input type="checkbox" name="is_notify" checked value="1"/>&nbsp;&nbsp;&nbsp;Notify to user</label>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
          <input type="submit" class="btn btn-primary" value="Active" />
        </div>
      </div>
    </form>
    </div>
  </div>

@include('components.backBtn')
@endsection
@push('js')
   <script>
       $('.btn-dlt').on('click',function(e){
          $('#deleteModal').modal('show');
       });
       $('.btn-deactive').on('click',function(e){
          $('#deactiveModal').modal('show');
       });
       $('.btn-active').on('click',function(e){
          $('#activeModal').modal('show');
       });
   </script>
@endpush
