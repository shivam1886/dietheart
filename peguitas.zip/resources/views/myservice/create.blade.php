@extends('layouts.loggedIn')

@section('title') Add Service @endsection

@section('content')

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Add Service </h3>
    </div>
</div>
<br/>
        <div class="row">
            <div class="col-md-6 col-offset-md-3">
                <div class="card">
                    <div class="card-body">
                        <form class="form" action="{{route('store.myservice')}}" method="POST">
                            @csrf
                            <div class="form-group">
                                <select class="form-control" name="category">
                                      <option value="">Select Category</option>
                                    @foreach(App\Models\Category::orderBy('title','asc')->get() as $key => $value)  
                                      <option @if(old('category') == $value->id ) selected @endif value="{{$value->id}}">{{$value->title}}</option>
                                    @endforeach
                                </select>
                                @error('category')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="service">
                                      <option value="">Select Service</option>
                                </select>
                                @error('service')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="service_cost" value="{{old('service_cost')}}" placeholder="Serivce Cost" required/>
                                @error('service_cost')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label>
                                    <input type="checkbox" name="is_active" value="1"/> Active
                                </label>
                            </div>
                            <input type="submit" value="Add" class="btn btn-primary float-right"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>

@include('components.backBtn')
@endsection
@push('js')
 <script>
        //Image Preview
        $('input[name="service_image"]').on('change',function(e){
            tmppath = URL.createObjectURL(event.target.files[0]);
            $('.image-preview').attr('src',tmppath);
        });
        $('.btn-dlt').on('click',function(e){
            e.preventDefault();
            $('#deleteModal').modal('show');
        });
        
        var categoryId = null;
        var serviceId  = null;
        @if(old('category'))
            categoryId = "{{old('category')}}";
        @endif
        @if(old('service'))
             serviceId = "{{old('service')}}";
        @endif

        var getService = function(categoryId){
            $.ajax({
               'type' : 'GET',
               'url'  : "{{url('/ajax/get/services?category_id=')}}" + categoryId,
               'success' : function(response){
                   console.log(response);
                   var html = '';
                   if(response.status){
                       response.data.map(function(service,index){
                           selected = '';
                           if(serviceId == service.service_id)
                                 selected = 'selected';
                           if(index == 0){
                              html += `<option value="">Select Service</option>`;
                           }
                           html += `<option ${selected} value="${service.service_id}">${service.service}</option>`;
                       });
                   }else{
                       html += `<option value="">{{__('Service not availabe')}}</option>`;
                   }
                      $('select[name="service"]').html(html);
               },
               'error' : function(error){
                   console.log(error);
               }
            });
        }

        if(categoryId){
            getService(categoryId);
        }

        $('select[name="category"]').on('change',function(e){
              e.preventDefault();
              getService(e.target.value);
        });

 </script>
@endpush