<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\ProductImage;

class ShoppingCart extends Model
{
   protected $table = 'shopping_carts';
}
