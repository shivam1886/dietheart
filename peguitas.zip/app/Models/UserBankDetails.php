<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\ProductImage;

class UserBankDetails extends Model
{
   protected $table = 'user_bank_details';
}
